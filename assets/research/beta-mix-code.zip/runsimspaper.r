## Where stuff is stored
topDir = '~/Dropbox/Daniel/Beta Mixing'
codeDir = 'code'
outputDir = 'output'
dataDir = 'data'
gfxDir = 'gfx'

newParameters = FALSE

if(newParameters){

#############
## Simulation Parameters
#############
## Discrete processes
nSimul = 1000
nobsSimul = 1000
aSimul = 1:10
dSimul = 1:4
alphaCI = .05
mMarkovSimul = 100
mMarkovd = 1:5
mMarkovNobs = 50000
mMarkov = 4

##AR(1) parameters
aAR = 1:6
dAR = 1
rhoAR = 0.5
nobsAR = c(100, 1000, 1e4, 1e5, 1e6)
sigmaAR = 1
nInnerInt = 5e2
nOuterInt = 5e2
nbinsAR = 2:91
nsampsCalAR = 50
nSimulAR = 250


##############
## Real data parameters
##############
aRec = c(1, 1:12*30)
dRec = c(1, 2, 5, 10, 20)
aTurb = 1:10*10
dTurb = 1:3

##############
## Graphical parameters
##############
figHeight = 8
figWidth = 12

save.image(file=paste(topDir, outputDir, 'currentParms.Rdata', sep='/'))
print('Current parameters saved. Previous values overwritten.')

}else{
  load(file=paste(topDir, outputDir, 'currentParms.Rdata',sep='/'))
  print('Previous parameter values loaded.')
}

## What to evaluate
reSimulateDiscrete = FALSE
reCalibrateAR = FALSE
reSimulateAR = FALSE
reSimulateMarkovM = FALSE
reEstimateRec = FALSE
reEstimateTurb = FALSE
generateFigs = TRUE



source(paste(topDir, codeDir, 'betaMixFunctions.R', sep='/'))
source(paste(topDir, codeDir, 'mMarkovFunctions.R', sep='/'))

## Simulations
if(reSimulateDiscrete){
  print('Running discrete simulations.')
    
    ## Markov process
    set.seed(8443,kind="L'Ecuyer")
    MarkovProcess = list()
    MarkovProcess$estimates = simplify2array(lapply(integer(nSimul),
        function(x) estimateMarkov(nobsSimul, aSimul, dSimul)))
    MarkovProcess$mean = apply(MarkovProcess$estimates, c(1,2), mean)
    MarkovProcess$CI = apply(MarkovProcess$estimates, c(1,2), quantile,
        probs=c(alphaCI/2, 1-alphaCI/2))
    
    set.seed(8448,kind="L'Ecuyer")
    MarkovProcess2 = list()
    MarkovProcess2$estimates = simplify2array(lapply(integer(nSimul/10),
                                                    function(x) estimateMarkov(100*nobsSimul, aSimul, dSimul))) 
    MarkovProcess2$mean = apply(MarkovProcess2$estimates, c(1,2), mean)
    MarkovProcess2$CI = apply(MarkovProcess2$estimates, c(1,2), quantile,
                             probs=c(alphaCI/2, 1-alphaCI/2))

    print('Markov process complete.')
    ## Even process
    set.seed(8444,kind="L'Ecuyer")
    EvenProcess = list()
    EvenProcess$estimates = simplify2array(lapply(integer(nSimul),
        function(x) estimateEven(nobsSimul, aSimul, dSimul)))
    EvenProcess$mean = apply(EvenProcess$estimates, c(1,2), mean)
    EvenProcess$CI = apply(EvenProcess$estimates, c(1,2), quantile,
        probs=c(alphaCI/2, 1-alphaCI/2))
  
    print('Even process complete.')
    save(MarkovProcess, MarkovProcess2, EvenProcess, file=paste(topDir, outputDir, 'DiscreteSimulationResults.Rdata', sep='/'))
    print('Discrete simulation results saved.')
}

if(reSimulateMarkovM){
  print('Running m-Markov simulations.')
  set.seed(8447,kind="L'Ecuyer")
  MarkovMProcess = list()
  MarkovMProcess$estimates = simplify2array(lapply(integer(mMarkovSimul), 
                  function(x) estimateMarkovM(mMarkovNobs, mMarkov, aSimul, mMarkovd)))
  MarkovMProcess$mean = apply(MarkovMProcess$estimates, c(1,2), mean)
  MarkovMProcess$CI = apply(MarkovMProcess$estimates, c(1,2), quantile,
                           probs=c(alphaCI/2, 1-alphaCI/2))
  print('m-Markov process complete.')
  save(MarkovMProcess, file=paste(topDir, outputDir, 
                'MarkovMSimulationResults.Rdata', sep='/'))
  print('m-Markov simulation results saved.')
}

if(reSimulateAR){
  if(reCalibrateAR){
    print('Running AR simulation.')
    ## AR process
    set.seed(8445,kind="L'Ecuyer")
    ARProcess = list()
    ARProcess$TrueBetas = arBetaCalc(1:10, rhoAR, sigmaAR, nOuterInt, nInnerInt)
    ARProcess$binsCalib = list()
    bestBins = double(length(nobsAR))
    for(i in 1:length(nobsAR)){
      print(paste('nobs=',i,sep=''))
      ARProcess$binsCalib[[i]] = calibrateBeta(arima.sim(list(ar=rhoAR), n=nobsAR[i],
        sd=sigmaAR), 1, nsampsCalAR, 2:91)
      bestBins[i] = ARProcess$binsCalib[[i]]$bestBins
    }
    save(ARProcess, file=paste(topDir, outputDir, 'ARSimulationResults.Rdata', sep='/'))
  }
  load(file=paste(topDir, outputDir, 'ARSimulationResults.Rdata', sep='/'))
  set.seed(8446, kind="L'Ecuyer")
  ARProcess$estimates = list()
  for(i in 1:length(nobsAR)){
    ARProcess$estimates[[i]] = matrix(NA, nrow=length(aAR), ncol=nSimulAR)
    for(j in 1:nSimulAR){
      ARProcess$estimates[[i]][,j] = estimateAR(nobsAR[i], aAR, dAR, bestBins[i], rhoAR, sigmaAR)
      print(paste('nobs=',i,'Sim',j,'/',nSimulAR,sep=''))
    }
  }
#     ARProcess$estimates = simplify2array(mclapply(integer(nSimulAR),
#         function(x) estimateAR(nobsAR, aAR, dAR, bestBins,
#                                rhoAR, sigmaAR), mc.cores=nnodes))
  ARProcess$mean = sapply(ARProcess$estimates,  rowMeans)
  ARProcess$CI = simplify2array(lapply(ARProcess$estimates, function(x) apply(x,1,quantile,
      probs=c(alphaCI/2, 1-alphaCI/2))))
dim(ARProcess$CI) = c(2,1,length(nobsAR))
  print('AR process complete.')
  
#     set.seed(8446,kind="L'Ecuyer")
#     ARProcessECDF = list()
#     ARProcessECDF$TrueBetas = ARProcess$TrueBetas
#     ARProcessECDF$binsCalib = calibrateBeta(arima.sim(list(ar=rhoAR),
#         n=nobsAR, sd=sigmaAR), 1, nsampsCalAR, nbinsAR, eCDF=TRUE)
#     bestBins = ARProcessECDF$binsCalib$bestBins
#     ARProcessECDF$estimates = simplify2array(mclapply(integer(nSimul),
#         function(x) estimateAR(nobsAR, aAR, dAR, rep(bestBins, length(dAR)),
#                                rhoAR, sigmaAR, eCDF=TRUE), mc.cores=nnodes))
#     ARProcessECDF$mean = apply(ARProcess$estimates, c(1,2), mean)
#     ARProcessECDF$CI = apply(ARProcess$estimates, c(1,2), quantile,
#         probs=c(alphaCI/2, 1-alphaCI/2))
#     print('AR ECDF version complete.')  

    ## Save output
    save(ARProcess, #ARProcessECDF,
         file=paste(topDir, outputDir, 'ARSimulationResults.Rdata', sep='/'))
}


## Data example
if(reEstimateRec){
    ## Recessions
  
    print('Running recession estimation.')
    require(parallel)
    load(paste(topDir, dataDir, 'recessionIndex.Rdata', sep='/'))
    rec = recess[,-c(1,2)] # first two columns are dates
    ad = expand.grid(aRec=aRec, dRec=dRec)
    recessBetas = mcmapply(estimBeta, a=ad$aRec, d=ad$dRec,
        MoreArgs = list(y = rec, discrete=TRUE), mc.cores=nnodes)
    dim(recessBetas) = c(length(aRec), length(dRec))
    rownames(recessBetas) = aRec
    colnames(recessBetas) = dRec
    save(recessBetas, file=paste(topDir, outputDir,
                          'RecessionResults.Rdata', sep='/'))
    print('Recession estimation complete.')
}

# if(reEstimateTurb){
#     ## Turbulence
#     print('Running turbulence estimation.')
#     turb = scan(paste(topDir, dataDir, 'dowmans-data/turbulence-data',
#         sep='/'), skip=1)
#     ad = expand.grid(aTurb=aTurb, dTurb=dTurb)
#     turbBetas = list()
#     turbBetas$binsCalib = mclapply(dTurb, function(x) calibrateBeta(turb, x,
#         nsampsCalTurb, nbinsTurb), simplify=FALSE)
#     bestBins = lapply(turbBetas$binsCalib, function(x) x$bestBins)
#     bestBins = rep(bestBins, each=length(aTurb))
#     turbBetas$estimates = mcmapply(estimBeta, a=ad$aTurb, d=ad$dTurb,
#         nbins=bestBins, MoreArgs=list(y=turb), mc.cores=nnodes)
#     dim(turbBetas$estimates) = c(length(aTurb), length(dTurb))
#     rownames(turbBetas$estimates) = aTurb
#     colnames(turbBetas$estimates) = dTurb
#     save(turbBetas, file=paste(topDir, outputDir, 'TurbulenceResults.Rdata', sep='/'))
#     print('Turbulence estimation complete.')
# }

## Graphics
if(generateFigs){
  print('Generating figures. Previous figures overwritten.')
  load(paste(topDir, outputDir, 'DiscreteSimulationResults.Rdata', sep='/'))
    load(paste(topDir, outputDir, 'ARSimulationResults.Rdata', sep='/'))
    load(paste(topDir, outputDir, 'RecessionResults.Rdata', sep='/'))
    load(paste(topDir, outputDir, 'MarkovMsimulationResults.Rdata', sep='/'))

    ## Markov process
    betaMarkov = 4/9 * (1/2) ^ aSimul
    paperSimPlot(betaMarkov, MarkovProcess, aSimul, dSimul,
              paste(topDir, gfxDir, 'MarkovExample.pdf', sep='/'), figWidth, figHeight,
              pch=figPch(length(dSimul)))
    paperSimPlot(betaMarkov, MarkovProcess2, aSimul, dSimul,
                 paste(topDir, gfxDir, 'MarkovExample2.pdf', sep='/'), figWidth, figHeight,
                 pch=figPch(length(dSimul)),ylim=c(0,max(MarkovProcess$CI)))

    ## Even process
    betaEven = 8/9 * (1/2) ^ aSimul
    paperSimPlot(betaEven, EvenProcess, aSimul, dSimul,
              paste(topDir, gfxDir, 'EvenExample.pdf', sep='/'), figWidth, figHeight,
              pch=figPch(length(dSimul)))
    
    ## m-Markov process
    betasMMarkov = matrix(NA, nrow = max(aSimul), ncol = mMarkov)
    Pmat = MarkovMPmat(mMarkov)
    sta = getStationaryMarkovM(Pmat)
    for(dd in 1:mMarkov){
      for(aa in aSimul){
        betasMMarkov[aa, dd] =  bMixMarkov(aa, dd, Pmat, sta)
      }
    }
    paperSimPlotM(betasMMarkov, MarkovMProcess, aSimul, mMarkovd,
                  paste(topDir, gfxDir, 'MarkovMExample.pdf', sep='/'), 
                  figWidth, figHeight, pch=figPch(length(mMarkovd)),
                  lty=mMarkov:1)
    
    ## AR
    paperSimPlot(ARProcess$TrueBetas, ARProcess, aAR, nobsAR,
              paste(topDir, gfxDir, 'ARExample.pdf', sep='/'), figWidth, figHeight,
              pch=figPch(length(nobsAR)))

    ## Recessions
    paperDataPlot(recessBetas, paste(topDir, gfxDir, 'Recession.pdf', sep='/'),
                  figWidth, figHeight, lty=3)
}
