lagMat1 <- function(y, nlags){
    n = length(y)
    m = n - nlags +1
    data = y[1:m + rep.int(nlags:1, rep.int(m,nlags))-1]
    dim(data) = c(m, nlags)
    return(data)
}

lagMatMulti <- function(y, nlags){
    n = nrow(y)
    p = ncol(y)
    m = n - nlags +1
    data = y[1:m + rep.int(nlags:1, rep.int(m*p, nlags)) - 1
        + rep.int(rep(0:(p-1)*n, each=m),nlags)]
    dim(data) = c(m, nlags*p)
    return(data)
}

sepMat <- function(y, a, d=1){
    n = length(y)
    nlags = d*a + 1
    m = n - nlags + 1
    if(m<0) stop(paste('The product of a =',a, 'and d =',d,'exceeds n=',n))
    data = y[1:m + rep.int(c(nlags, 1), rep.int(m, 2)) -1]
    dim(data) = c(m, 2)
    return(data)
}

bindFill <- function(a,b){
  lcolsA = names(a)
  lcolsB = names(b)
  cols = union(lcolsA,lcolsB) # use union?
  output = matrix(0, nrow = 2, ncol = length(cols))
  colnames(output) = cols
  output[1,lcolsA] = a
  output[2,lcolsB] = b
  return(output)
}

estimBetaDisc <- function(y, a, d=1){
    y = as.matrix(y)
    y = apply(y, 1, paste, collapse='')
    if(d>1) y = apply(lagMat1(y, d), 1, paste, collapse='')
    sep = factor(apply(sepMat(y, a, d), 1, paste, collapse=''))
    y = factor(y)
    histf = table(y)/length(y)
    histsep = table(sep)/length(sep)
    histfxf = c(outer(histf,histf))
    names(histfxf) = outer(levels(y),levels(y),paste0)
    mat = bindFill(histfxf,histsep)
    estimate = sum(abs(mat[1,] - mat[2,]))/2
    return(estimate)
}


binCont <- function(y, nbins, ran=range(y)){
    ## Bins continuous data to get discrete data
    h = (ran[2] - ran[1]) /nbins
    if(nbins > 91) stop("can't use more than 91 bins")
    extras=c('!','@','#','$','%','^','&','*','(',')','-','_','+','=','[',']','{','}',';',':',',','.','<','>','/','?','|','`','~')
    binnames = c(0:9,letters, LETTERS,extras)[1:nbins]
    X = pmin(floor( (y - ran[1])/ h), nbins-1) + 1
    X = binnames[X]
    dim(X) <- dim(y)
    return(X)
}



estimBetaECDF <- function(y, nbins, a, d){
  y = as.matrix(y)
  y = apply(y, 2, rank)/dim(y)[1]
  binned = binCont(y, nbins, c(0,1))
  p = dim(binned)[2] * d * 2
  y = apply(binned, 1, paste, collapse='')
  if(d>1) y = apply(lagMat1(y, d), 1, paste, collapse='')
  sep = factor(apply(sepMat(y, a, d), 1, paste, collapse=''))
  histSep = table(sep)/length(sep)
  totalBins = nbins^p
  emptyBins = (totalBins - length(histSep))/totalBins
  estimate = .5 * sum(abs(1/totalBins-histSep)) + .5 * emptyBins
  return(estimate)
}
    

estimBeta <- function(y, nbins=2, a=1, d=1, discrete=FALSE, standard=TRUE, eCDF=FALSE){
    if(discrete){
      out = estimBetaDisc(y, a, d)
      return(out)
    }
    if(eCDF) return(estimBetaECDF(y, nbins, a, d))
    if(standard) y = scale(y)
    binned = binCont(y, nbins)
    out = estimBetaDisc(binned, a, d)
    return(out)
}

seriesResamp1 <- function(y, d, roundDown = TRUE, prob=.5){
  y = as.matrix(y)
  n = nrow(y)
  p = ncol(y)
  m = ifelse(roundDown, floor(n/(2*d)), ceiling(n/(2*d))) * 2 # need even m
  ## vec = ifelse(circular, c(1:n, 1:(d-1)), 1:(n-d+1)) # which points can start the blocks
  select = c(TRUE, runif(m-1) > prob)
  samps = sample.int(n-d+1, sum(select), replace=TRUE)
  select = samps[cumsum(select)]
  blocks = sapply(select, function(x) x+0:(d-1)) # matrix with m cols,
                                        #       # rows give d-blocks
  dim(blocks) = c(1, m*d)
  ytilde = y[blocks, ]
  return(ytilde)
}

getKappa <- function(y, d, tol=1e-6){
    lagged = lagMatMulti(y, d)
    
    
}

probDiag <- function(nbins, y, d){
    binned = binCont(y, nbins)
    y = apply(binned, 1, paste, collapse='')
    if(d>1) y = apply(lagMat1(y, d), 1, paste, collapse='')
    y = factor(y)
    pDiag = sum(( table(y) / length(y))^2)
    return(pDiag)
}

calibrateBeta <- function(y, d, nsamp, nbins, checkUnique=FALSE,
                          roundDown=TRUE, eCDF=FALSE){
    print(paste('Calibrating bins via bootstrap estimation with',nsamp,'samples.'))
    y = as.matrix(y)
    n = nrow(y)
    if(checkUnique){
        kappa = getKappa(y, d)
    }else{
        kappa = 1 / (n - d + 1)
    }
    pDiag = sapply(nbins, probDiag, y=y, d=d)
    BetaD = .5 * (1 - pDiag) * (1 - kappa)
    ## BetaD = (1 - kappa) * (3*d - 1) / (4*d)
    ytilde = replicate(nsamp, seriesResamp1(y, d, roundDown))
    dimmax = length(dim(ytilde))
    q = length(nbins)
    estimates = matrix(NA, q, nsamp)
    for(jj in 1:q){
      print(paste(nbins[jj],'/',nbins[q]))
        estimates[jj,] = apply(ytilde, dimmax, estimBeta, nbins=nbins[jj],
                     a=1, d=d, eCDF=eCDF)
    }
    errs = estimates - BetaD
    out = list()
    out$target = BetaD
    out$mse = rowMeans(errs^2)
    out$bias = rowMeans(errs)
    out$bestBins = nbins[which.min(out$mse)]
    out$BiasofBest = out$bias[which.min(out$mse)]
    return(out)
}

## Markov chain generation
simMarkov2state <- function(n){
    states = c(0,1)
    Transition = matrix(c(.5,.5,1,0),nrow=2,byrow=TRUE)
    stationary = c(2/3,1/3)
    x = double(n)
    x[1] = sample(states, 1, prob=stationary)
    for(i in 2:n){
        x[i] = sample(states, 1, prob=Transition[x[i-1]+1,])
    }
    return(x)
}

simEvenProcess <- function(n){
    y = simMarkov2state(n+1) 
    y2 = cbind(y[-(n+1)], y[-1])
    x = apply(y2, 1, function(x) any(x==1))
    return(list(latent=y[-n], even=as.integer(x)))
}

estimateMarkov <- function(nobs, a, d){
    y = simMarkov2state(nobs)
    combos = expand.grid(a, d)
    beta.markov = mapply(estimBeta, a=combos[,1], d=combos[,2],
        MoreArgs=list(y=y, discrete=TRUE))
    dim(beta.markov) = c(length(a), length(d))
    return(beta.markov)
}

estimateEven <- function(nobs, a, d){
    y = simEvenProcess(nobs)$even
    combos = expand.grid(a, d)
    beta.even = mapply(estimBeta, a=combos[,1], d=combos[,2],
        MoreArgs=list(y=y, discrete=TRUE))
    dim(beta.even) = c(length(a), length(d))
    return(beta.even)
}

estimateAR <- function(nobs, a, d, nbins, rho=0.5, sigma=1, eCDF=FALSE){
    y = arima.sim(list(ar=rho), nobs, sd=sigma)
    combos = expand.grid(a, d)
    beta.ar = mapply(estimBeta, a=combos[,1], d=combos[,2],
        nbins = nbins, MoreArgs=list(y=y, eCDF=eCDF))
    dim(beta.ar) = c(length(a), length(d))
    return(beta.ar)
}



simpsons.int <- function(fun, xvec){
  ## fun is the function to integrate, xvec is the (sorted) vector of
  ## evaluation points
  
  n = length(xvec)
  a = xvec[1]
  b = xvec[n]
  
  ## Trapezoid method
  y = fun(xvec)
  idx = 2:n
  T = (xvec[idx] - xvec[idx-1]) %*% (y[idx] + y[idx-1]) / 2
  
  ## Midpoint method
  h = (b-a)/n
  x.m = a[1] + c(h/2, h/2 + h*1:(n-1))
  y.m = fun(x.m)
  M = sum(y.m * h)
  
  return( (2*M + T)/3 )
}

arBetaCalc <- function(a, rho, sig, n.out = 100, n.in = 100, far = 5){
  num = length(a)
  a = sort(a, dec = FALSE) # check that a is in ascending order

  pp = 1
  mu.pi = 0
  Sig.pi = sig/(1-rho^2)
  
  Sig.m = sig
  AGA = rho * sig * rho
  mu.m = rho * rnorm(n.out, mu.pi, Sig.pi)
  beta = double(num)
  count = 1
  for(i in 1:num){
    while(a[i]>count){
      Sig.m = Sig.m + AGA
      AGA = rho^2 * AGA
      mu.m = rho * mu.m
      count = count + 1
    }
    ## Inner integral
    x = seq(mu.pi - far * Sig.pi, mu.pi + far * Sig.pi, length=n.in)
    in1 = double(n.out)
    for(j in 1:n.out) in1[j] = .5 * simpsons.int(function(z) abs(dnorm(z, mu.pi, Sig.pi)
                          - dnorm(z, mu.m[j], Sig.m)), x)
    beta[i] = sum(in1)/n.out
  }
  return(beta)
}

calibrateAR1 <- function(nbins, nobs, nsamps, truebeta,
                            rho, sigma){
    ytilde = replicate(nsamps, arima.sim(list(ar=rho), nobs, sd=sigma))
    q = length(nbins)
    estimates = matrix(NA, nsamps, q)
    for(jj in 1:q){
        estimates[,jj] = apply(ytilde, 2, estimBeta, nbins=nbins[jj], a=1, d=1)
        print(c(jj, '/', q))
    }
    errs = estimates - truebeta
    mse = colMeans(errs^2)
    bias = colMeans(errs)
    best = list(target=truebeta, bestBins=nbins[which.min(mse)],
        BiasofBest=bias[which.min(mse)])
    return(list(best=best, mse=mse, bias=bias))
}
        
testARcalibration <- function(nbins, nobs, nsamps, rho, sigma){
    yIID = replicate(nsamps, rnorm(nobs, 0, sigma/(1-rho^2)))
    yAR = replicate(nsamps, arima.sim(list(ar=rho), nobs, sd=sigma))
    IIDresamp = apply(yIID, 2, seriesResamp, d=1)
    ARresamp = apply(yAR, 2, seriesResamp, d=1)
    q = length(nbins)
    estimates = list()
    estimates$AR = matrix(NA, nsamps, q)
    estimates$IID = matrix(NA, nsamps, q)
    estimates$ARboot = matrix(NA, nsamps, q)
    estimates$IIDboot = matrix(NA, nsamps, q)
    for(jj in 1:q){
        print(c(jj,'/',q))
        estimates$AR[,jj] = apply(yAR, 2, estimBeta, nbins=nbins[jj], a=1, d=1, eCDF=TRUE)
        # estimates$IID[,jj] = apply(yIID, 2, estimBeta, nbins=nbins[jj], a=1, d=1)
        estimates$ARboot[,jj] = apply(ARresamp, 2, estimBeta, nbins=nbins[jj],
                            a=1, d=1, eCDF=TRUE)
        # estimates$IIDboot[,jj] = apply(IIDresamp, 2, estimBeta, nbins=nbins[jj], a=1, d=1)
    }
    # estimateMeans = lapply(estimates, colMeans)
    return(estimates)
}

figPch <- function(n){
    figPts = c(19:17, 15, 6:1)
    return(figPts[1:n])
}


paperSimPlot <- function(targetBeta, Output, aa, dd, filename, figWidth,
                      figHeight, mar = c(5,6,0,0)+.1, bty='n', las=1, family='serif',
                      xlab='a', ylab=expression(beta(a)), cex.labels=1, line=2.5,
                      lty=3, pch=figPch(length(dd)), col=rep(1,length(pch)),
                      space.inflate=.1,ylim=NULL){
    pdf(file = filename, width=figWidth, height=figHeight)
    par(mar = mar, bty=bty, las=las, family=family)
    if(is.null(ylim)) ylim = c(0, max(Output$CI, targetBeta))
    xlim = range(aa) + c(-.5,.5)*space.inflate*(length(dd)+1)
    # xlim[2] = xlim[2] + space.inflate*(length(dd)+1)
    plot(targetBeta, ty='l', ylim=ylim, xlim=xlim, xlab=xlab, ylab='', cex.lab=cex.labels, lty=lty)
    mtext(ylab, 2, cex=cex.labels, line=line, las=las)
    xx = outer(aa, scale((1:length(dd))*space.inflate, scale=FALSE), '+')[,,,drop=TRUE]
    for(ii in 1:length(dd)) segments(xx[,ii], Output$CI[1,,ii],
                                         xx[,ii], Output$CI[2,,ii])
    matpoints(xx, Output$mean, pch=pch, col=col)
    dev.off()
}

paperDataPlot <- function(Output, filename, figWidth, figHeight, mar = c(5,6,0,0)+.1,
                          bty='n', las=1, family='serif', type='b',
                          xlab='a', ylab=expression(beta(a)), cex.labels=1, line=2.5,
                          lty=seq_int(ncol(Output)), pch=figPch(ncol(Output)),
                          col=rep(1,ncol(Output))){
    pdf(file = filename, width=figWidth, height=figHeight)
    par(mar=mar, bty=bty, las=las, family=family)
    aa = as.numeric(rownames(Output))
    dd = as.numeric(colnames(Output))
    matplot(aa, Output, type=type, lty=lty, pch=pch, col=col, xlab=xlab, ylab='',
            cex.lab=cex.labels)
    mtext(ylab, 2, cex=cex.labels, line=line, las=las)
    legend('topright', legend=as.expression(lapply(dd, function(x) bquote(gamma==.(x)))),
           lty=lty, pch=pch, col=col,bty='n')
    dev.off()
}
