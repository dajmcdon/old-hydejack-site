MarkovMPmat <- function(m){
  pfun1 <- function(x){
    past = mean(x)
    p = ((m-1) * (1-past) + (past)) / m
  }
  l = lapply(1:m, function(x) c(0,1))
  states = expand.grid(l)
  nstates = 2^m
  probs1 = apply(states, 1, pfun1)
  probs0 = 1 - probs1
  states = apply(states, 1, paste0, collapse='')
  pos1 = rep((nstates/2+1):nstates, each=2)
  pos0 = rep(1:(nstates/2), each=2)
  Pmat = matrix(0, nstates, nstates)
  Pmat[cbind(1:nstates, pos1)] = probs1
  Pmat[cbind(1:nstates, pos0)] = probs0
  dimnames(Pmat) = list(states, states)
  return(Pmat)
}
  
getStationaryMarkovM <- function(Pmat){
  nstates = dim(Pmat)[1]
  eye = diag(nstates)
  ones = rep(1, nstates)
  onesones = ones %*% t(ones)
  stat = solve(t(eye - Pmat + onesones), ones)
  return(stat)
}


bMixMarkov <- function(a, d, Pmat, sta){
  require(expm)
  m = nchar(rownames(Pmat)[1])
  if(d > m-1) d = m
  matReduce <- function(n, r) {
    suppressWarnings(matrix(c(rep(1, n / r), rep(0, n)), n, r))
  }
  nstates = length(sta)
  mult = matReduce(nstates, 2^d) 
  MD = d:m
  bmix = double(m-d+1)
  for(ii in 1:(m-d+1)){
    joint = t(mult) %*% (sta * Pmat %^% (MD[ii]+a-1)) %*% mult
    indep = t(mult) %*% sta %*% t(sta) %*% mult
    bmix[ii] = 0.5 * sum(abs(joint - indep))
  }
  return(max(bmix))
}

# bMixMarkov <- function(a, Pmat, sta){
#   require(expm)
#   nstates = dim(Pmat)[1]
#   ones = rep(1, nstates)
#   hist = abs(Pmat %^% a - ones %*% t(sta))
#   bmix = sum(sta * hist)
#   return(0.5 * bmix)
# }


# bMixMarkovD <- function(a, d, Pmat, sta){
#   require(expm)
#   m = nchar(rownames(Pmat)[1])
#   if(d > m-1) return(bMixMarkov(a, m, Pmat, sta))
#   matReduce <- function(n, r) {
#     suppressWarnings(matrix(c(rep(1, n / r), rep(0, n)), n, r))
#   }
#   nstates = length(sta)
#   mult = matReduce(nstates, 2^d) 
#   newPmat = t(mult) %*% Pmat %*% mult * 2^d / nstates
#   newsta = getStationaryMarkovM(newPmat)
#   return(bMixMarkov(a, d, newPmat, newsta))
# }
  
  
paperSimPlotM <- function(targetBeta, Output, aa, dd, filename, figWidth,
                         figHeight, mar = c(5,6,0,0)+.1, bty='n', las=1, family='serif',
                         xlab='a', ylab=expression(beta(a)), cex.labels=1, line=2.5,
                         lty=3, pch=figPch(length(dd)), col=rep(1,length(pch)),
                         space.inflate=.1){
  pdf(file = filename, width=figWidth, height=figHeight)
  par(mar = mar, bty=bty, las=las, family=family)
  ylim = c(0, max(Output$CI, targetBeta))
  xlim = range(aa) + c(-.5,.5)*space.inflate*(length(dd)+1)
  matplot(targetBeta, ty='l', ylim=ylim, xlim=xlim, xlab=xlab, ylab='',
          cex.lab=cex.labels, lty=lty, col=1)
  mtext(ylab, 2, cex=cex.labels, line=line, las=las)
  xx = outer(aa, scale((1:length(dd))*space.inflate, scale=FALSE), '+')[,,,drop=TRUE]
  for(ii in 1:length(dd)) segments(xx[,ii], Output$CI[1,,ii],
                                   xx[,ii], Output$CI[2,,ii])
  matpoints(xx, Output$mean, pch=pch, col=col)
  dev.off()
}

simMarkovM <- function(n, m){
  transMat = MarkovMPmat(m)
  sta = getStationaryMarkovM(transMat)
  nstates = length(sta)
  states = rownames(transMat)
  outSeq = integer(n)
  outSeq[1] = sample.int(nstates, 1, prob = sta)
  for(ii in 2:n){
    outSeq[ii] = sample.int(nstates, 1, prob = transMat[outSeq[ii-1],])
  }
  outStatesM = states[outSeq]
  outStates = as.integer(c(strsplit(outStatesM[1],split=NULL)[[1]], 
                           substr(outStatesM[2:n],m,m)))
  return(outStates)
}

estimateMarkovM <- function(nobs, m, a, d){
  y = simMarkovM(nobs, m)
  combos = expand.grid(a, d)
  beta.MarkovM = mapply(estimBeta, a=combos[,1], d=combos[,2],
                     MoreArgs=list(y=y, discrete=TRUE))
  dim(beta.MarkovM) = c(length(a), length(d))
  return(beta.MarkovM)
}
  
